<?php
include ('conn.php');
       if ($_FILES["image"]["error"] > 0)
       {
       echo "error";
       }else{
              move_uploaded_file($_FILES["image"]["tmp_name"],"images/" . $_FILES["image"]["name"]);
              echo"move" ;

              $file="images/".$_FILES["image"]["name"];
              $name=$_FILES["image"]["name"];
              $sql="INSERT INTO upload_images(id,image_name,paths) VALUES ('','$name','$file')";
              if(mysqli_query($conn,$sql))
                echo "image url updated successfully";
              else   
                 echo "image upload error";
       }



?>

<html>
              <head>
              <title>images Upload</title>
              </head>

              <body>
                 
     <form action="Upload.php" method="post" enctype="multipart/form-data">
     <input name="image" accept="image/jpeg" type="file">
     
            <input type="submit" name="upload" value="Upload " >   

     </from>
              
              
              </body>

</html>