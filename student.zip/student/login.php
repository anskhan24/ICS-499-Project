<?php
    session_start();
    
    require_once('conn.php');
    if(isset($_POST['save']))
    {
        $email = $_POST['email'];
        $password = md5($_POST['password']);
        
        $sql = "SELECT * FROM fundraisers where email='$email' AND password='$password'";
        if($result = mysqli_query($conn, $sql))   
        {
            if(mysqli_num_rows($result)>0)
            {
                $row = mysqli_fetch_array($result);
                $_SESSION["username"] = $row['name'];
                $_SESSION["isadmin"] = $row['check_admin'];
                echo "<script>window.location.href='backend/index.php'</script>";
              // if($row['check_admin']==1)
               // echo "<script>window.location.href='super_admin/admin.php'</script>";
              //  else 
              //  {
                    
               //     $_SESSION["username"] = $row['name'];
              //      echo "<script>window.location.href='super_admin/user.php'</script>";
               // }
            } else 
            echo "<script>alert('Check your username & Password')</script>";
        }
        else  
        echo "Connection Error";
    } 
    
    
    
    
?>

<?php include 'includes/header.php';?>




        
        
        
        
        <!-----login --->
        <section class="login">
            
            
            <div class="form">
                <h1>Log in</h1>
                <form class="register-form" action="login.php" method="POST">
                    <input  name="email" type="text" placeholder="email"/>   
                    <input name="password" type="password" placeholder="password"/>
                    
                    <button type="submit" name="save">Login</button>
                    <p class="message">Not registered? <a href="registration.php">Create an account</a></p>
                </form> 
            </div>
            
        </section>
        
        
		
     <?php include 'includes/footer.php';?>