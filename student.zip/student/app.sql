-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2019 at 07:01 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `app`
--

-- --------------------------------------------------------

--
-- Table structure for table `donate`
--

CREATE TABLE `donate` (
  `transaction_id` int(16) NOT NULL,
  `organisation_id` int(16) NOT NULL,
  `organisation_name` varchar(16) NOT NULL,
  `donated_by` varchar(16) NOT NULL,
  `creditcard_number` int(16) NOT NULL,
  `creditcard_cvv_number` int(16) NOT NULL,
  `creditcard_expiry_date` date NOT NULL,
  `donated_date` date NOT NULL,
  `amount` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donate`
--

INSERT INTO `donate` (`transaction_id`, `organisation_id`, `organisation_name`, `donated_by`, `creditcard_number`, `creditcard_cvv_number`, `creditcard_expiry_date`, `donated_date`, `amount`) VALUES
(4, 1, '', '', 24234, 234, '2019-11-08', '0000-00-00', 234),
(5, 1, '', '', 234, 234, '2019-11-01', '0000-00-00', 234),
(6, 1, 'myname', '', 52342, 234, '2019-11-07', '0000-00-00', 234),
(7, 1, '', '', 34243, 234, '2019-11-03', '0000-00-00', 2342),
(8, 1, '', '', 234, 234, '2019-11-09', '0000-00-00', 234),
(9, 1, '', '', 0, 0, '2019-11-03', '0000-00-00', 0),
(10, 1, '', '', 324, 234, '2019-11-08', '0000-00-00', 0),
(11, 1, '', '', 3423, 234, '2019-11-01', '0000-00-00', 234),
(12, 1, '', '', 23424, 24, '2019-11-09', '0000-00-00', 3423),
(13, 1, '', '', 234, 234, '0000-00-00', '0000-00-00', 0),
(14, 1, '', '', 234234, 234, '0000-00-00', '0000-00-00', 234),
(15, 1, '', 'admin', 234, 34, '0000-00-00', '0000-00-00', 234),
(16, 1, '', 'admin', 34523423, 234, '2019-11-16', '0000-00-00', 234234);

-- --------------------------------------------------------

--
-- Table structure for table `fundraisers`
--

CREATE TABLE `fundraisers` (
  `id` int(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` int(12) NOT NULL,
  `address` text NOT NULL,
  `check_admin` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fundraisers`
--

INSERT INTO `fundraisers` (`id`, `name`, `email`, `password`, `phone`, `address`, `check_admin`) VALUES
(9, 'aravind', 'aravindpv17@gmail.com', 'b691c96a0e0e2674df4943221d5b4767', 0, '', 0),
(11, 'aravind kumar', 'aravindbr94@gmail.com', '0c3e2e312377f7fad9d8aed2bc8d3a7a', 0, '', 1),
(12, 'murugan', 'murugan@gmail.com', 'c96c85dc415f4eda477f0beca80ea61b', 0, '', 0),
(13, 'murugank', 'murugankaliyankvm@gmail.com', 'cd17c651450f01b44644441fb68bcf90', 0, '', 0),
(33, 'salim', 'salimhariz@gmail.com', '5c792ab5a27f615dc22f6732e29b1ee6', 3903, 'klsd', 0),
(34, 'admin', 'admin@admin.com', 'e10adc3949ba59abbe56e057f20f883e', 99092432, 'Chennai', 1);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `imagename` varchar(30) NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `organisations`
--

CREATE TABLE `organisations` (
  `id` int(16) NOT NULL,
  `name` varchar(16) NOT NULL,
  `type` varchar(16) NOT NULL,
  `email` varchar(16) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `address` varchar(16) NOT NULL,
  `country` varchar(16) NOT NULL,
  `accno` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organisations`
--

INSERT INTO `organisations` (`id`, `name`, `type`, `email`, `phone`, `address`, `country`, `accno`) VALUES
(1, 'blood bank', '', 'bb@bb.com', '9393939', 'address street', '', 324234234);

-- --------------------------------------------------------

--
-- Table structure for table `upload_images`
--

CREATE TABLE `upload_images` (
  `id` int(50) NOT NULL,
  `image_name` varchar(100) NOT NULL,
  `paths` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `upload_images`
--

INSERT INTO `upload_images` (`id`, `image_name`, `paths`) VALUES
(2, 'delhi schools.jpg', 'images/delhi schools.jpg'),
(3, 'baby products.jpg', 'images/baby products.jpg'),
(4, '', 'images/'),
(5, 'karuna.jpg', 'images/karuna.jpg'),
(6, 'Desert.jpg', 'images/Desert.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donate`
--
ALTER TABLE `donate`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `fundraisers`
--
ALTER TABLE `fundraisers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uname` (`name`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organisations`
--
ALTER TABLE `organisations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `upload_images`
--
ALTER TABLE `upload_images`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `image_name` (`image_name`),
  ADD UNIQUE KEY `path` (`paths`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donate`
--
ALTER TABLE `donate`
  MODIFY `transaction_id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `fundraisers`
--
ALTER TABLE `fundraisers`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `organisations`
--
ALTER TABLE `organisations`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `upload_images`
--
ALTER TABLE `upload_images`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
