<?php include 'includes/header.php';?>







  <!--==========================
    Intro Section
  ============================-->
  <section id="intro" class="clearfix">
    <div class="container">

      <div class="intro-img" id="intro-img-banner">
        <img src="img/intro-img.png" alt="" class="img-fluid">
      </div>

      <div class="intro-info">
        <h2>We raise<br><span>fund</span><br>for noble causes!</h2>
        <div>
          <a href="registration.php" class="btn-get-started scrollto">Get Started</a>
          <a href="#services" class="btn-services scrollto">Our Services</a>
        </div>
      </div>

    </div>
  </section><!-- #intro -->

  <main id="main">

    <!--==========================
      About Us Section
    ============================-->
    <section id="about">
      <div class="container">

        <header class="section-header">
          <h3>About Us</h3>
          <p>We raise funds for a noble cause.</p>
        </header>

        <div class="row about-container">

          <div class="col-lg-6 content order-lg-1 order-2" id="about-content">
            <p>
              This is a college project. This is a college project. This is a college project. This is a college project. 

            <div class="icon-box wow fadeInUp">
              <div class="icon"><i class="fa fa-shopping-bag"></i></div>
              <h4 class="title"><a href="">This is a college project. </a></h4>
              <p class="description">This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. </p>
            </div>

            <div class="icon-box wow fadeInUp" data-wow-delay="0.2s">
              <div class="icon"><i class="fa fa-photo"></i></div>
              <h4 class="title"><a href="">This is a college project. </a></h4>
              <p class="description">This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. </p>
            </div>

            <div class="icon-box wow fadeInUp" data-wow-delay="0.4s">
              <div class="icon"><i class="fa fa-bar-chart"></i></div>
              <h4 class="title"><a href="">This is a college project. </a></h4>
              <p class="description">This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. </p>
            </div>

          </div>

          <div class="col-lg-6 background order-lg-2 order-1 wow fadeInUp" id="about-img">
            <img src="img/about-img.svg" class="img-fluid" alt="">
          </div>
        </div>

        <div class="row about-extra">
          <div class="col-lg-6 wow fadeInUp " id="about-extra">
            <img src="img/about-extra-1.svg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 wow fadeInUp pt-5 pt-lg-0" id="about-extra-1">
                <h4>This is a college project. This is a college project. This is a college project. </h4>
                <p>
                 This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. 
                </p>
                <p>
                  This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. 
                </p>

              </div>
          </div>
        </div>

        <div class="row about-extra">
            <div class="col-lg-6 wow fadeInUp pt-4 pt-lg-0 order-2 order-lg-1" id="order">
                <h4>This is a college project. This is a college project. This is a college project. </h4>
                <p>
                 This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. 
                </p>
                <p>
                  This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. 
                </p>
                <p>
                 This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. This is a college project. 
                </p>
              </div>
          <div class="col-lg-6 wow fadeInUp order-1 order-lg-2" id="about-extra-2">
            <img src="img/about-extra-2.svg" class="img-fluid" alt="">
          </div>

          
          
        </div>

      </div>
    </section><!-- #about -->

    <!--==========================
      Services Section
    ============================-->
    <section id="services" class="section-bg">
      <div class="container">

        <header class="section-header">
          <h3>What we do?</h3>
          <p>We fund for the below non profit organizations</p>
        </header>

        <div class="row">

          <div  id="service-plan" class="col-md-6 col-lg-5 offset-lg-1 wow bounceInUp" data-wow-duration="1.4s">
            <div class="box">
              <div class="icon"><i class="ion-ios-analytics-outline" style="color: #ff689b;"></i></div>
              <h4 class="title"><a href=""><img src="img/planned-parenthood-logo.png"></a></h4>
              <p class="description"> In October 2016, Planned Parenthood turned 100 years strong. Planned Parenthood was founded on the revolutionary idea that women should have the information and care they need to live strong, healthy lives and fulfill their dreams — no ceilings, no limits</p>
            </div>
          </div>
          <div id="service-heart" class="col-md-6 col-lg-5 wow bounceInUp" data-wow-duration="1.4s">
            <div class="box">
              <div class="icon"><i class="ion-ios-bookmarks-outline" style="color: #e9bf06;"></i></div>
              <h4 class="title"><a href=""><img src="img/american-heart-association-logo.png"></a></h4>
              <p class="description">American Heart Association: he six cardiologists who founded the American Heart Association in 1924 would be amazed.
From humble beginnings, the AHA has grown into the nation’s oldest and largest voluntary organization dedicated to fighting heart disease and stroke.</p>
            </div>
          </div>

          <div  id="service-red"class="col-md-6 col-lg-5 offset-lg-1 wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
            <div class="box">
              <div class="icon"><i class="ion-ios-paper-outline" style="color: #3fcdc7;"></i></div>
              <h4 class="title"><a href=""><img src="img/american-red-cross-logo.png"></a></h4>
              <p class="description">Each day, thousands of people – people just like you – provide compassionate care to those in need. Our network of generous donors, volunteers and employees share a mission of preventing and relieving suffering, here at home and around the world.</p>
            </div>
          </div>
          <div  id="service-speed" class="col-md-6 col-lg-5 wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
            <div class="box">
              <div class="icon"><i class="ion-ios-speedometer-outline" style="color:#41cf2e;"></i></div>
              <h4 class="title"><a href=""><img src="img/chippa-logo.jpg"></a></h4>
              <p class="description">CHHIPA WELFARE, a non-profit welfare organization in Pakistan, imbued with a noble mission, having sincere love and affection for the humanity and a strong commitment to serve the COMMON PEOPLE without discrimination of any caste, creed or colour under all circumstances</p>
            </div>
          </div>

          

        </div>

      </div>
    </section><!-- #services -->



    <!--==========================
      Contact Section
    ============================-->
    <section id="contact">
      <div class="container-fluid">

        <div class="section-header">
          <h3>Contact Us</h3>
        </div>

        <div class="row wow fadeInUp" id="contact-us">

         

          <div class="col-lg-6" id="contact-map1">
            <div class="row" id="contac-icon">
              <div  id="contact-address" class="col-md-5 info" >
                  <i class="fa fa-map-marker" aria-hidden="true"></i>
                <!-- <i class="ion-ios-location-outline"></i> -->
                <p>A108 Adam Street, NY 535022</p>
              </div>
              <div  id="contact-email" class="col-md-4 info" >
                <!-- <i class="ion-ios-email-outline"></i> -->
                <i class="fa fa-envelope-o" aria-hidden="true"></i>
                <p>info@example.com</p>
              </div>
              <div id="contact-phone" class="col-md-3 info">
                <!-- <i class="ion-ios-telephone-outline"></i> -->
                <i class="fa fa-phone" aria-hidden="true"></i>
                <p>+1 5589 55488 55</p>
              </div>
            </div>

            <div class="form">
              <div id="sendmessage">Your message has been sent. Thank you!</div>
              <div id="errormessage"></div>
              <form action="" method="post" role="form" class="contactForm">
                <div class="form-row">
                  <div class="form-group" id="fname">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    <div class="validation"></div>
                  </div>
                  <div class="form-group" id="lname">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                    <div class="validation"></div>
                  </div>
                </div>
                <div class="form-group" id="subject">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                  <div class="validation"></div>
                </div>
                <div class="form-group" id="contact-message">
                  <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                  <div class="validation"></div>
                
                <div class="button-text-center"><button type="submit" id="button-msg" title="Send Message">Send Message</button></div>
              </form>
           
          </div>

        </div>

      </div>
    </section><!-- #contact -->

  </main>

 <?php include 'includes/footer.php';?>