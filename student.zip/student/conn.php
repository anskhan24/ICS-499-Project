<?php
$host = "localhost";
$user = "root";
$password = "";
$db="app";

// Create connection
$conn=mysqli_connect($host,$user,$password,$db);


// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

?>