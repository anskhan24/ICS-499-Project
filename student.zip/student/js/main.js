
        function test()
        {
         var link=document.getElementById("nav-collapse");
         if(link.style.display==="block")
            link.style.display="none";
          else
            link.style.display="block";
        }

