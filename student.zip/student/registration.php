<?php
    require_once('conn.php');
    
    
    if(isset($_POST['save'])){
        $name =$_POST['name'];
        $email =$_POST['email'];
        $password =md5($_POST['password']);
        $phone =$_POST['phone'];
        $address =$_POST['address'];
        
        
        if(empty($name) && empty($email) && empty($password) && empty($phone) && empty($adress))
        {
            echo "please field the field";
        }else
        {
            
            $sql = "INSERT INTO fundraisers (name, email,password,phone,address,check_admin) VALUES ('$name', '$email', '$password','$phone','$address',0)";
            
            
            if(mysqli_query($conn, $sql)){
                echo  "<script>alert('Register successfully'); window.location.href='login.php' </script>";
            }
            else
            {
                echo "<script> 
               alert('Error');
                //document.getElementById('reg-error').write('Register Error');
                window.location.href='registration.php';
                
                </script>";
            }
        }
        
        
    }
    
    
?>

<?php include 'includes/header.php';?>


<!--======Registration=======
============================-->

<section class="register">
    
    <div class="form">
        <h1>Registration</h1>
        <span id="reg-error"></span>
        <form class="register-form" action="" method="POST">
            <input name="name" type="text" placeholder="name"/>
            
            <input name="email" type="text" placeholder="email address"/>
            <input  name="password" type="password" placeholder="password"/>
            <input  name="phone" type="text" placeholder="phone"/>
            <input  name="address" type="text" placeholder="address"/>
            <button type="submit" name="save">Register</button>
            <p class="message">Already registered? <a href="login.php">Sign In</a></p>
        </form>
    </div>
    
</section>











<?php include 'includes/footer.php';?>