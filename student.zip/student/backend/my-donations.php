
<?php
    session_start();
    
    require_once('../conn.php');
    ?>
    
<?php include 'includes/header.php';?>
<section class="content-container">
    
    <div class="sidebar"><?php include 'includes/sidebar.php';?></div>
    <div class="content">
        <h1>My Donations</h1>
        <?php 
           
            
            if($_SESSION["isadmin"] ==  1)
                echo '<a href="create-organisation.php" targe="_self" class="btn-regular primary">Create Organisations</a>';
         ?>
        
        <div class="profile-data">
            <?php 
                $username = $_SESSION["username"]; 
                
                $sql = "SELECT * FROM donate where donated_by ='$username'";
                
                
                
                
                
                
                echo '<table class="data-table" border="0" cellspacing="0" cellpadding="0"> 
                <tr> 
                <th>Transaction ID</th> 
                <th>Organisation Name</th> 
                <th>Donated Date</th> 
                <th>Donated Amount</th> 
               
               
                </tr>';
                
                if ($result = $conn->query($sql)) {
                    while ($row = $result->fetch_assoc()) {
                        $field1name = $row["transaction_id"];
                        $field2name = $row["organisation_name"];
                        $field3name = $row["donated_date"];
                        $field4name = $row["amount"];
                       
                        
                        echo '<tr> 
                        <td>'.$field1name.'</td> 
                        <td>'.$field2name.'</td> 
                        <td>'.$field3name.'</td> 
                        <td>'.$field4name.'</td> 
                       
                        
                        </tr>';
                    }
                    $result->free();
                } 
            ?>
        </table>
        
    </div>
    </div>
</section>
<?php include 'includes/footer.php';?>