<?php
   session_start();
    
    require_once('../conn.php');
    
    
    if(isset($_POST['save'])){
        
        $organisation_id = $_POST['organisation_id'];
        $organisation_name = $_POST['organisation_name'];
        $donated_by = $_POST['donated_by'];
        $creditcard_number =$_POST['creditcard_number'];
        $creditcard_cvv_number =$_POST['creditcard_cvv_number'];
        $creditcard_expiry_date =$_POST['creditcard_expiry_date'];
        $donated_date =$_POST['donated_date'];
        $amount =$_POST['amount'];
        
     
        
        
        if(empty($organisation_name) && empty($donated_by) && empty($creditcard_number) && empty($creditcard_cvv_number) && empty($creditcard_expiry_date)  && empty($amount))
        {
            echo "please field the field";
        }else
        {
            	
            $sql = "INSERT INTO donate (organisation_id, organisation_name, donated_by, creditcard_number, creditcard_cvv_number, creditcard_expiry_date, donated_date, amount) VALUES ('$organisation_id', '$organisation_name', '$donated_by', '$creditcard_number', '$creditcard_cvv_number', '$creditcard_expiry_date', '$donated_date', '$amount')";
            
            
            if(mysqli_query($conn, $sql)){
                echo  "<script>alert('Donated successfully'); window.location.href='organisation.php' </script>";
            }
            else
            {
                echo "<script> 
               alert('Error');
                //document.getElementById('reg-error').write('Register Error');
                window.location.href='organisation.php';
                
                </script>";
            }
        }
        
        
    }
    
    
?>

<?php include 'includes/header.php';?>
<section class="content-container">
    
    <div class="sidebar"><?php include 'includes/sidebar.php';?></div>
    <div class="content">
        <h1>Donate an Organisation</h1>

    <section class="create-organisations">
    
    <div class="form">
        <h1>Donate</h1>
        <span id="reg-error"></span>
        <?php //echo $_GET['orgid']; 
            
             $orgsql = "SELECT * FROM organisations where id='" . $_GET['orgid'] . "'";
              
                if ($result = $conn->query($orgsql)) {
                    while ($row = $result->fetch_assoc()) {
                        $orgname = $row["name"];
                        }
            }
            ?>
        <form class="register-form" action="" method="POST">
            <input type="hidden" name="organisation_id" value="<?php echo $_GET['orgid']; ?>" />
            
            <label>Organisation Name</label>
            <input name="organisation_name" type="text" value="<?php echo $orgname; ?>"  disabled />
            
            <label>Donated by</label>
            <input name="donated_by" type="text" value="<?php echo $_SESSION['username']; ?>" disabled />
            
            <label>Enter Credit card Number</label>
            <input  name="creditcard_number" type="text" placeholder="16 Digit credit card number"/>
            
            <label>Enter Credit card CVV Number</label>
            <input  name="creditcard_cvv_number" type="text" placeholder="3 Digit credit card CVV number"/>
            
            <label>Enter Credit card Expiry date</label>
            <input  name="creditcard_expiry_date" type="date" placeholder="Credit card expiry date"/>
            
            <label>Date</label>
            <input  name="donated_date" type="text" value="<?php echo  date('m/d/Y h:i:s a', time());?>" placeholder="Donated on"/>
          
            <label>Amount</label>
            <input  name="amount" type="text" placeholder="Enter the amount"/>
            
            <button type="submit" name="save">Donate Now</button>
           
        </form>
    </div>
    
</section>
</div>










<?php include 'includes/footer.php';?>