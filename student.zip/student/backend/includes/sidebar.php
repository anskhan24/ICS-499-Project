<ul class="menu">
    <li><a href="index.php">Profile</a></li>
    <li><a href="organisation.php">Organisations</a></li>
    <li><a href="my-donations.php">My donations</a></li>
    </ul>