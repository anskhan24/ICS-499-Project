<?php
    session_start();
    
    require_once('../conn.php');
    
    
?>
<?php include 'includes/header.php';?>
<section class="content-container">
    
    <div class="sidebar"><?php include 'includes/sidebar.php';?></div>
    <div class="content">
        <h1>My Profile</h1>
        <h2>Welcome <strong><?php echo $_SESSION["username"]; ?></strong></h2>
        <div class="profile-data">
            <?php 
                $username = $_SESSION["username"]; 
                
                $sql = "SELECT * FROM fundraisers where name='$username'";
                
                
                
                
                
                
                echo '<table class="data-table" border="0" cellspacing="0" cellpadding="0"> 
                <tr> 
                <th> <font face="Arial">User ID</font> </th> 
                <th> <font face="Arial">Name</font> </th> 
                <th> <font face="Arial">Email</font> </th> 
                <th> <font face="Arial">Phone</font> </th> 
                <th> <font face="Arial">Address</font> </th> 
                </tr>';
                
                if ($result = $conn->query($sql)) {

                    while ($row = $result->fetch_assoc()) {
                        $field1name = $row["id"];
                        $field2name = $row["name"];
                        $field3name = $row["email"];
                        $field4name = $row["phone"];
                        $field5name = $row["address"]; 
                        
                        echo '<tr> 
                        <td>'.$field1name.'</td> 
                        <td>'.$field2name.'</td> 
                        <td>'.$field3name.'</td> 
                        <td>'.$field4name.'</td> 
                        <td>'.$field5name.'</td> 
                        </tr>';
                    }
                    $result->free();
                } 
            ?>
        </table>
        
    </div>
</div>
</section>
<?php include 'includes/footer.php';?>

