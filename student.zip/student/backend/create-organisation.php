<?php
   session_start();
    
    require_once('../conn.php');
    
    
    if(isset($_POST['save'])){
        $name =$_POST['name'];
        $email =$_POST['email'];

        $phone =$_POST['phone'];
        $address =$_POST['address'];
        $accno =$_POST['accno'];
        
        
        if(empty($name) && empty($email) && empty($phone) && empty($adress) && empty($acc-no))
        {
            echo "please field the field";
        }else
        {
            
            $sql = "INSERT INTO organisations (name, type, email,phone,address,country, accno) VALUES ('$name', '$type','$email', '$phone','$address','$country','$accno')";
            
            
            if(mysqli_query($conn, $sql)){
                echo  "<script>alert('Register successfully'); window.location.href='organisation.php' </script>";
            }
            else
            {
                echo "<script> 
               alert('Error');
                //document.getElementById('reg-error').write('Register Error');
                window.location.href='organisation.php';
                
                </script>";
            }
        }
        
        
    }
    
    
?>

<?php include 'includes/header.php';?>
<section class="content-container">
    
    <div class="sidebar"><?php include 'includes/sidebar.php';?></div>
    <div class="content">
        <h1>Organisations</h1>

    <section class="create-organisations">
    
    <div class="form">
        <h1>Create Organisation</h1>
        <span id="reg-error"></span>
        <form class="register-form" action="" method="POST">
            <input name="name" type="text" placeholder="Organisation Name"/>
            <input name="type" type="text" placeholder="Eg: NGO"/>
            <input name="email" type="text" placeholder="Email Address"/>
            <input  name="phone" type="text" placeholder="Phone"/>
            <input  name="address" type="text" placeholder="Address"/>
            <input  name="country" type="text" placeholder="Country"/>
            <input  name="accno" type="text" placeholder="Bank Account Number"/>
            <button type="submit" name="save">Create</button>
           
        </form>
    </div>
    
</section>
</div>










<?php include 'includes/footer.php';?>